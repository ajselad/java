import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainFrame extends JFrame {
    public static KontrolliLojes kontrolliLojes;
    private final JLabel thesareLabel;
    private final JLabel piketLabel;
    private final JLabel coordinatesLabel;

    public MainFrame(int game) {
        // Initialize frame properties
        this.setTitle("SantaMaze");
        kontrolliLojes = new KontrolliLojes(this);
        if (game == KonstanteLoje.NEW_GAME)
            kontrolliLojes.filloLojen();
        else if (game == KonstanteLoje.SAVED_GAME)
            kontrolliLojes.filloLojen("save.dat");
        ImageIcon icon = new ImageIcon("C:\\Users\\Kejdi\\IdeaProjects\\SantaMaze\\src\\figura\\pema.png");
        this.setIconImage(icon.getImage());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(590, 700);
        setLayout(new BorderLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);

        // Set the background color
        Color backgroundColor = new Color(0xb3ccda);
        getContentPane().setBackground(backgroundColor);

        // Maze Panel
        JPanel mazePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // Calculate cell size based on screen dimensions
                int screenWidth = getWidth();
                int screenHeight = getHeight();
                int cellSize = Math.min(screenWidth / KonstanteLoje.KOLONA, screenHeight / KonstanteLoje.RRESHTA);

                // Calculate the starting point to center the labyrinth
                int xOffset = (screenWidth - (KonstanteLoje.KOLONA * cellSize)) / 2;
                int yOffset = (screenHeight - (KonstanteLoje.RRESHTA * cellSize)) / 2;

                // Set the cell size in the KontrolliLojes instance
                Labirint.cellSize = cellSize;

                // Clear the panel before repainting
                g.setColor(getBackground());
                g.fillRect(0, 0, getWidth(), getHeight());

                // Repaint the maze with the updated cell size and starting point
                kontrolliLojes.labirint.printoLabirintin(g, xOffset, yOffset);
            }
            {
                setBackground(backgroundColor);
            }
        };
        add(mazePanel, BorderLayout.CENTER);

        // Button Panel
//        JPanel buttonPanel = new JPanel(new GridLayout(2, 2));
//
//        ImageIcon iconUp = new ImageIcon("C:\\Users\\Kejdi\\IdeaProjects\\SantaMaze\\src\\figura\\shigjetaUp.png");
//        ImageIcon iconLeft = new ImageIcon("C:\\Users\\Kejdi\\IdeaProjects\\SantaMaze\\src\\figura\\shigjetaLeft.png");
//        ImageIcon iconDown = new ImageIcon("C:\\Users\\Kejdi\\IdeaProjects\\SantaMaze\\src\\figura\\shigjetaDown.png");
//        ImageIcon iconRight = new ImageIcon("C:\\Users\\Kejdi\\IdeaProjects\\SantaMaze\\src\\figura\\shigjetaRight.png");
//
//        JButton buttonUp = new JButton(iconUp);
//        JButton buttonDown = new JButton(iconDown);
//        JButton buttonLeft = new JButton(iconLeft);
//        JButton buttonRight = new JButton(iconRight);
//
//        buttonUp.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                kontrolliLojes.luajRradhen("lart");
//                updateLabels();
//                repaint();
//            }
//        });
//
//        buttonDown.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                kontrolliLojes.luajRradhen("poshte");
//                updateLabels();
//                repaint();
//            }
//        });
//
//        buttonLeft.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                kontrolliLojes.luajRradhen("majtas");
//                updateLabels();
//                repaint();
//            }
//        });
//
//        buttonRight.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                kontrolliLojes.luajRradhen("djathtas");
//                updateLabels();
//                repaint();
//            }
//        });
//
//        buttonPanel.add(buttonUp);
//        buttonPanel.add(buttonDown);
//        buttonPanel.add(buttonLeft);
//        buttonPanel.add(buttonRight);
//
//        add(buttonPanel, BorderLayout.SOUTH);

        // Add key listener to mazePanel
        mazePanel.setFocusable(true);
        mazePanel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e.getKeyCode());
            }
        });

        // Label Panel
        thesareLabel = new JLabel("Treasures found: " + kontrolliLojes.lojtar.thesareTeMbledhura);
        piketLabel = new JLabel("Points: " + kontrolliLojes.lojtar.piket);
        coordinatesLabel = new JLabel("Coordinates: (" + kontrolliLojes.lojtar.pozicioniRresht + ", " + kontrolliLojes.lojtar.pozicioniKolone + ")");
        JButton menu = new JButton("Exit Game");
        menu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GameMenu gameMenu = new GameMenu();
                gameMenu.setVisible(true);
            }
        });

        JPanel labelPanel = new JPanel(new GridLayout(1, 3));
        labelPanel.add(thesareLabel);
        labelPanel.add(piketLabel);
        labelPanel.add(coordinatesLabel);
        labelPanel.add(menu);

        add(labelPanel, BorderLayout.NORTH);

        // Frame settings
        setVisible(true);
        setLocationRelativeTo(null); // Center the frame on the screen
        SwingUtilities.invokeLater(mazePanel::requestFocusInWindow);
    }

    // Update labels with new values
    public void updateLabels() {
        thesareLabel.setText("Treasures found: " + kontrolliLojes.lojtar.thesareTeMbledhura);
        piketLabel.setText("Points: " + kontrolliLojes.lojtar.piket);
        coordinatesLabel.setText("Koordinatat: (" + kontrolliLojes.lojtar.pozicioniRresht + ", " + kontrolliLojes.lojtar.pozicioniKolone + ")");
    }

    // Method to handle key press events
    private void handleKeyPress(int keyCode) {
        switch (keyCode) {
            case KeyEvent.VK_UP:
                kontrolliLojes.luajRradhen("lart");
                break;
            case KeyEvent.VK_DOWN:
                kontrolliLojes.luajRradhen("poshte");
                break;
            case KeyEvent.VK_LEFT:
                kontrolliLojes.luajRradhen("majtas");
                break;
            case KeyEvent.VK_RIGHT:
                kontrolliLojes.luajRradhen("djathtas");
                break;
        }
        updateLabels();
        repaint();
    }
}

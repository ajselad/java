public class KonstanteLoje {
    public static int RRESHTA = 11;
    public static int KOLONA = 21;
    public static int THESARE_TOTALE = 10;
    public final static int NEW_GAME = 0;
    public final static int SAVED_GAME = 1;
}


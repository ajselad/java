public class Lojtar {
    public int pozicioniRresht;
    public int pozicioniKolone;
    public int thesareTeMbledhura;
    public int piket;

    public Lojtar(int pozicioniRresht, int pozicioniKolone) {
        this.pozicioniRresht = pozicioniRresht;
        this.pozicioniKolone = pozicioniKolone;
        Labirint.labirint[pozicioniRresht][pozicioniKolone] = 9;
    }

    public void leviz(int rreshtIRi, int koloneERe) {
        Labirint.labirint[this.pozicioniRresht][this.pozicioniKolone] = 0;
        Labirint.labirint[rreshtIRi][koloneERe] = 9;
        this.pozicioniRresht = rreshtIRi;
        this.pozicioniKolone = koloneERe;
    }

    public void mblidhThesar() {
        this.thesareTeMbledhura++;
        this.piket += 10;
        Labirint.labirint[pozicioniRresht][pozicioniKolone] = 0;
    }

    public boolean eshteNeDalje() {
        return (this.pozicioniRresht == Labirint.rreshtiDaljes && this.pozicioniKolone == Labirint.kolonaDaljes);
    }
}
